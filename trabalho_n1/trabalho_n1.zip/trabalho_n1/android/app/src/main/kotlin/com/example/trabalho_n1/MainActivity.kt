package com.example.trabalho_n1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
